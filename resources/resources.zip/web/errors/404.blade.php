@extends('layouts.main')

@section('content')
<div class="col-xs-12 col-sm-9">
  <h1>404, Not found page!</h1>
</div>
@stop