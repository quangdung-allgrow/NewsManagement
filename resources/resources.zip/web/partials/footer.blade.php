<footer>
    <p>&copy; 2016 Company, Inc.</p>
</footer>