<ul class="nav nav-sidebar">
    <li class="{{ active_menu('dashboard.index') }}"><a href="{{ route('dashboard.index') }}">Dashboard</a></li>
    <li class="{{ active_menu('news/*') }}"><a href="{{ route('news.index') }}">News</a></li>
</ul>