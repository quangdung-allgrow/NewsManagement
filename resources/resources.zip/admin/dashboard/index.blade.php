@extends('layouts.master')

@section('title', 'Dashboard')

@section('content')
<h1 class="page-header">Dashboard</h1>
<div class="row">
	<div class="col-md-12">
		Dashboard
	</div>
</div>
@stop