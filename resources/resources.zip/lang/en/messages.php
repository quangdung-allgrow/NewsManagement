<?php

return [
    'permission denied' => 'Permission denied!'
];
