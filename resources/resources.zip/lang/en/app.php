<?php

return [
    'button' => [
        'save' => 'Save',
        'save and continue' => 'Save and continue',
        'cancel' => 'Cancel',
        'success' => 'Success!',
        'failed' => 'Failed!',
    ],
    'string' => [
    	 'aya sure' => 'Are you absolutely sure you want to delete this item?',
    ],
    'messages' => [
        'save item success' => 'Save item success!',
        'save item failed' => 'Save item failed!',
    ],
];
