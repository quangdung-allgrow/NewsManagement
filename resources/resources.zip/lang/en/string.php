<?php

return [
    'hello' => 'Hello'
];
