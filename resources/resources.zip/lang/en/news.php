<?php

return [
	'limit characters' => 'Limit :limit characters'
];
