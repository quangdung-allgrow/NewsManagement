<?php

return [
    'messages' => [
        'invalid login' => 'Invalid login information',
        'account lock' => 'Account blocked for :delay seconds',
        'sign in' => 'Sign In',
        'remember me' => 'Remember me',
        'please sign in' => 'Please sign in',
    ],
];
