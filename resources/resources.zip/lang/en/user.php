<?php

return [
    'string' => [
        'profile' => 'Profile',
    ],
];
